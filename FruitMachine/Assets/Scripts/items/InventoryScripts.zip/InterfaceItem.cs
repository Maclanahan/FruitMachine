﻿using UnityEngine;
using System.Collections;

public abstract class InterfaceItem : MonoBehaviour 
{
    public abstract bool isEmpty();
	
}
