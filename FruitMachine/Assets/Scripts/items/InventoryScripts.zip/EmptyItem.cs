﻿using UnityEngine;
using System.Collections;

public class EmptyItem : InterfaceItem{


    override public bool isEmpty()
    {
        return true;
    }
}
